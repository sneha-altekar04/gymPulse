<script setup>
import { computed } from 'vue';

import { formatCurrency } from '../../utils/formatters';

const props = defineProps({
  title: {
    type: String,
    required: true
  },
  value: {
    type: [String, Number],
    required: true
  },
  helper: {
    type: String,
    default: ''
  },
  icon: {
    type: String,
    required: true
  },
  tone: {
    type: String,
    default: 'primary'
  },
  format: {
    type: String,
    default: 'number'
  },
  context: {
    type: String,
    default: ''
  },
  trendText: {
    type: String,
    default: ''
  },
  progress: {
    type: Number,
    default: null
  },
  variant: {
    type: String,
    default: 'default'
  }
});

const formattedValue = computed(() => {
  if (props.format === 'currency') {
    return formatCurrency(Number(props.value));
  }

  return new Intl.NumberFormat('en-IN').format(Number(props.value));
});
</script>

<template>
  <article class="stat-card" :class="[`stat-card--${tone}`, `stat-card--${variant}`]">
    <span v-if="variant === 'dashboard'" class="stat-card__top-accent" aria-hidden="true" />
    <div class="stat-card__icon-wrap">
      <i :class="icon" class="stat-card__icon" aria-hidden="true" />
    </div>
    <div class="stat-card__content">
      <p class="stat-card__title">{{ title }}</p>
      <h3 class="stat-card__value">{{ formattedValue }}</h3>
      <p class="stat-card__helper">{{ helper }}</p>
      <p v-if="context" class="stat-card__context">{{ context }}</p>
      <p v-if="trendText" class="stat-card__trend">{{ trendText }}</p>
      <div v-if="progress !== null" class="stat-card__progress" role="presentation">
        <span :style="{ width: `${Math.max(Math.min(progress, 100), 0)}%` }" />
      </div>
    </div>
  </article>
</template>