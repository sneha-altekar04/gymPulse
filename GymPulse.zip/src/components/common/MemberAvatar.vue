<script setup>
import { computed } from 'vue';

const props = defineProps({
  name: {
    type: String,
    required: true
  },
  size: {
    type: String,
    default: 'md'
  },
  imageUrl: {
    type: String,
    default: ''
  }
});

const initials = computed(() => {
  return props.name
    .split(' ')
    .map((chunk) => chunk[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
});

const toneIndex = computed(() => {
  const value = props.name
    .split('')
    .reduce((sum, char) => sum + char.charCodeAt(0), 0);

  return (value % 4) + 1;
});
</script>

<template>
  <div
    class="member-avatar"
    :class="[`member-avatar--${size}`, `member-avatar--tone-${toneIndex}`]"
  >
    <img v-if="imageUrl" :src="imageUrl" :alt="name" class="member-avatar__image" />
    <span v-else>{{ initials }}</span>
  </div>
</template>
