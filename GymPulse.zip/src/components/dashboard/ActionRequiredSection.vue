<script setup>
import { useRouter } from 'vue-router';

const props = defineProps({
  items: {
    type: Array,
    required: true
  }
});

const router = useRouter();

function navigateTo(route) {
  router.push(route);
}
</script>

<template>
  <section class="panel-card dashboard-action-panel">
    <div class="panel-card__header">
      <div>
        <p class="panel-card__eyebrow">Priorities</p>
        <h2 class="panel-card__title">Action Required</h2>
      </div>
      <span class="panel-card__chip panel-card__chip--accent">Today</span>
    </div>

    <div class="action-grid">
      <button
        v-for="item in items"
        :key="item.id"
        type="button"
        class="action-item"
        :class="`action-item--${item.tone}`"
        @click="navigateTo(item.route)"
      >
        <div class="action-item__icon-wrap">
          <i :class="item.icon" class="action-item__icon" aria-hidden="true" />
        </div>
        <div class="action-item__body">
          <p class="action-item__count">{{ item.count }}</p>
          <p class="action-item__title">{{ item.title }}</p>
          <p class="action-item__detail">{{ item.detail }}</p>
        </div>
        <i class="pi pi-arrow-right action-item__arrow" aria-hidden="true" />
      </button>
    </div>
  </section>
</template>